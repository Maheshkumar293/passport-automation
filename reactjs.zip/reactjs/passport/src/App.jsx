import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import Navbar from './navbar';
import LoginPage from './login';

function App() {
  return (
    <div className="App bg-light min-vh-100 d-flex justify-content-center align-items-center position-relative">
         <LoginPage />
    </div>
  );
}

export default App;
