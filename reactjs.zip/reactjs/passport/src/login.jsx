import React, { useState } from 'react';
import axios from 'axios';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import bgImage from './assets/air/ChatGPT Image Apr 19, 2025, 04_42_03 PM.png';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');

  const login = async (e) => {
    e.preventDefault();
    const res = await axios.post('http://localhost:8080/api/login', { email, password, role });
    alert(res.data.success ? `Login successful as ${role}` : 'Invalid credentials');
  };

  return (
    <div
      className="min-vh-100 min-vw-100 d-flex justify-content-center align-items-center"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        fontFamily: "'Inter', sans-serif", // base font
      }}
    >
      <marquee
        behavior="scroll"
        direction="left"
        scrollamount="6"
        className="mb-4 fw-semibold fixed-top text-center"
        style={{
          fontSize: '1.2rem',
          background: 'rgba(0, 0, 0, 0.4)',
          padding: '12px 20px',
          borderRadius: '0 0 10px 10px',
          color: '#fff',
          fontFamily: "'Poppins', sans-serif", // headline
          letterSpacing: '0.5px',
          textShadow: '1px 1px 2px #000',
        }}
      >
        ✈️ Fasten your seatbelts! Register your passport now and fly your dreams 🌍🛫 | Hassle-free. Quick. Reliable. 🛂🗺️ | Let's take off into a world without borders! 🛬✨
      </marquee>

      <h1
        className='fixed-top'
        style={{
          margin: 70,
          textAlign: 'center',
          fontFamily: "'Poppins', sans-serif",
          fontWeight: '700',
          color: '#fff',
          textShadow: '1px 1px 2px #000',
        }}
      >
        WELCOME TO PASSPORT SEVA
      </h1>

      <div
        className="rounded-4 shadow-lg p-5"
        style={{
          background: 'rgba(255, 255, 255, 0.15)',
          backdropFilter: 'blur(15px)',
          WebkitBackdropFilter: 'blur(15px)',
          width: '100%',
          maxWidth: '400px',
          color: '#fff',
          fontFamily: "'Inter', sans-serif",
        }}
      >
        <h2 className="text-center fw-bold mb-4 text-black" style={{ fontFamily: "'Poppins', sans-serif" }}>
          Welcome Back
        </h2>

        <form onSubmit={login}>
          <div className="mb-3">
            <label className="form-label text-black">Email address</label>
            <input
              type="email"
              className="form-control bg-transparent text-black border-white"
              required
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
            />
          </div>

          <div className="mb-3">
            <label className="form-label text-black">Password</label>
            <input
              type="password"
              className="form-control bg-transparent text-black border-white"
              required
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
          </div>

          <div className="mb-4">
            <label className="form-label text-black">Login as</label>
            <select
              className="form-select bg-transparent text-black border-white"
              required
              onChange={(e) => setRole(e.target.value)}
              value={role}
            >
              <option value="" className="text-dark">Choose Role</option>
              <option value="user" className="text-dark">User</option>
              <option value="admin" className="text-dark">Admin</option>
              <option value="regionalAdmin" className="text-dark">Regional Admin</option>
              <option value="police" className="text-dark">Police</option>
            </select>
          </div>

          <button type="submit" className="btn btn-light fw-bold w-100">
            Login
          </button>
        </form>

        <p className="text-center text-white mt-4 small mb-0">
          &copy; 2025 <strong>YourAppName</strong>. All rights reserved.
        </p>
      </div>
    </div>
  );
}
