import React from 'react';
import { 
  Navbar,
  Nav,
  Container,
  NavDropdown,
  Form,
  Button
} from 'react-bootstrap';

export default function navbar() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary fixed-top">
      <Container fluid>
        <Navbar.Brand href="#">Navbar</Navbar.Brand>
        
        {/* Mobile toggle button */}
        <Navbar.Toggle aria-controls="navbarScroll" />
        
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link href="#" active>Home</Nav.Link>
            <Nav.Link href="#">Link</Nav.Link>
            
            {/* Working dropdown */}
            <NavDropdown title="Dropdown" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#">Action</NavDropdown.Item>
              <NavDropdown.Item href="#">Another action</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#">
                Something else here
              </NavDropdown.Item>
            </NavDropdown>
            
            <Nav.Link href="#" disabled>
              Disabled
            </Nav.Link>
          </Nav>
          
          {/* Search form */}
          <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}